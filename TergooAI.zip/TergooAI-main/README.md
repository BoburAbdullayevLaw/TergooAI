# TergooAI
O‘zbekiston huquq-tartibot organlari uchun sun’iy intellekt asosida huquqiy maslahat va tergov jarayonlarini avtomatlashtiruvchi tizim.
